
multipass transfer ./src/router/sr_router.c cn-a2:./assignments-fall24/Assignment2/src/router/sr_router.c
multipass transfer ./src/router/sr_router.h cn-a2:./assignments-fall24/Assignment2/src/router/sr_router.h
multipass transfer ./src/router/sr_arpcache.c cn-a2:./assignments-fall24/Assignment2/src/router/sr_arpcache.c
multipass transfer ./src/router/sr_arpcache.h cn-a2:./assignments-fall24/Assignment2/src/router/sr_arpcache.h
multipass transfer ./src/router/sr_if.c cn-a2:./assignments-fall24/Assignment2/src/router/sr_if.c
multipass transfer ./src/router/sr_if.h cn-a2:./assignments-fall24/Assignment2/src/router/sr_if.h
multipass transfer ./src/router/sr_utils.c cn-a2:./assignments-fall24/Assignment2/src/router/sr_utils.c
multipass transfer ./src/router/sr_utils.h cn-a2:./assignments-fall24/Assignment2/src/router/sr_utils.h
multipass transfer ./src/router/sr_rt.c cn-a2:./assignments-fall24/Assignment2/src/router/sr_rt.c
multipass transfer ./src/router/sr_rt.h cn-a2:./assignments-fall24/Assignment2/src/router/sr_rt.h