#!/bin/bash

sudo python topo.py
